package com.itwill.spring3.dto.email;

import lombok.Data;

@Data
public class EmailVerifyDto {
	private String email;
}
