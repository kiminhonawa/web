package com.itwill.spring3.dto.reply;

import lombok.Data;

@Data
public class ReplyUpdateDto {

    private String replyText;
    
}
